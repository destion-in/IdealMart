import 'package:flutter/material.dart';

class ProductCard extends StatelessWidget {
  final String imageUrl;
  final String productName;
  final double price;
  final double? offerPrice;

  const ProductCard({
    required this.imageUrl,
    required this.productName,
    required this.price,
    this.offerPrice,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 180,
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Color(0xFFF5F5F5),
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          // BoxShadow(
          //   color: Colors.grey.withOpacity(0.3),
          //   spreadRadius: 2,
          //   blurRadius: 5,
          //   offset: Offset(0, 3), // changes position of shadow
          // ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Image.network(
              imageUrl,
              height: 64,
            ),
          ),
          SizedBox(height: 15),
          Text(
            productName,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Row(
            children: [
              Text(
                '\$ $price/kg',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF275F61),
                ),
              ),
              if (offerPrice != null) ...[
                SizedBox(width: 8),
                Text(
                  '\$ $offerPrice/kg',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.normal,
                    color: Colors.red,
                    decoration: TextDecoration.lineThrough,
                  ),
                ),
              ]
            ],
          ),
          SizedBox(height: 8),
        ],
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      body: Center(
        child: ProductCard(
          imageUrl: 'https://cdn-icons-png.flaticon.com/128/415/415733.png',
          productName: 'Apples',
          price: 4,
          offerPrice: 5,
        ),
      ),
    ),
  ));
}

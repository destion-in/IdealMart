import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:iconsax/iconsax.dart';
import 'package:flutter/material.dart';
import 'package:idealmart/src/data/category_data.dart';
import 'package:idealmart/src/data/image_strings.dart';
import 'package:idealmart/src/data/products.dart';
import 'package:idealmart/src/ui/common/widgets/search_bar.dart';
import 'package:idealmart/src/widgets/category_card.dart';
import 'package:idealmart/src/widgets/image_container.dart';
import 'package:idealmart/src/widgets/product_card.dart';
import 'package:idealmart/src/widgets/section_header.dart';
import 'package:carousel_slider/carousel_slider.dart';

class HomeScreen extends StatefulWidget {
  final String userName;

  const HomeScreen({required this.userName, super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _current = 0;
  final CarouselController _controller = CarouselController();

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));

    return Scaffold(
      backgroundColor: Color(0xFF275F61),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(top: 4, bottom: 4),
              child: Column(
                children: [
                  Container(
                    padding: EdgeInsets.only(
                      left: 16,
                      right: 16,
                      top: 16,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Good day for shopping!",
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.normal,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              widget.userName,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                        IconButton(
                          icon: Icon(Iconsax.notification, color: Colors.white),
                          onPressed: () {},
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 8),
                  CustomSearchBar(),
                  SizedBox(height: 8),
                  Padding(
                    padding: EdgeInsets.only(left: 16, right: 16, bottom: 8),
                    child: Column(
                      children: [
                        SectionHeader(
                          title: "Categories",
                          actionText: "View All",
                          onActionTap: () {
                            // Handle "View All" tap
                          },
                          showAction: true,
                          color: Colors.white,
                        ),
                        SizedBox(height: 12),
                        CategoryList(categories: categories),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                color: Colors.white,
                width: double.infinity,
                padding: EdgeInsets.only(
                  left: 16,
                  right: 16,
                  top: 22,
                  // bottom: 16,
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SectionHeader(
                        title: "Special Deals for You",
                        actionText: "View All",
                        onActionTap: () {
                          // Handle "View All" tap
                        },
                        showAction: true,
                        color: Colors.black,
                      ),
                      const SizedBox(height: 12),
                      CarouselSlider(
                        items: ImageAssets.sliderImages.map((item) {
                          return Builder(
                            builder: (BuildContext context) {
                              return CustomImageContainer(
                                imageUrl: item,
                                height: 180.0,
                                width: MediaQuery.of(context).size.width * 0.8,
                                borderRadius: 12.0,
                              );
                            },
                          );
                        }).toList(),
                        carouselController: _controller,
                        options: CarouselOptions(
                          viewportFraction: 0.9,
                          height: 180.0,
                          autoPlay: true,
                          autoPlayInterval: Duration(seconds: 3),
                          autoPlayAnimationDuration:
                              Duration(milliseconds: 800),
                          autoPlayCurve: Curves.fastOutSlowIn,
                          pauseAutoPlayOnTouch: true,
                          aspectRatio: 2.0,
                          onPageChanged: (index, reason) {
                            setState(() {
                              _current = index;
                            });
                          },
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: ImageAssets.sliderImages
                            .asMap()
                            .entries
                            .map((entry) {
                          return GestureDetector(
                            onTap: () => _controller.animateToPage(entry.key),
                            child: Container(
                              width: _current == entry.key ? 24 : 10,
                              height: 6.0,
                              margin: EdgeInsets.symmetric(
                                  vertical: 10.0, horizontal: 4.0),
                              decoration: BoxDecoration(
                                color: _current == entry.key
                                    ? const Color(0xFF275F61).withOpacity(0.9)
                                    : Colors.grey,
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 12),
                      SectionHeader(
                        title: "Popular Products",
                        actionText: "View All",
                        onActionTap: () {
                          // Handle "View All" tap
                        },
                        showAction: true,
                        color: Colors.black,
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: MediaQuery.of(context).size.width * 0.5,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: popularProducts.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.only(right: 16),
                              child: ProductCard(
                                imageUrl: popularProducts[index].imageUrl,
                                productName: popularProducts[index].productName,
                                price: popularProducts[index].price,
                                offerPrice: popularProducts[index].offerPrice,
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 12),
                      SectionHeader(
                        title: "Latest Products",
                        actionText: "View All",
                        onActionTap: () {
                          // Handle "View All" tap
                        },
                        showAction: true,
                        color: Colors.black,
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: MediaQuery.of(context).size.width * 0.5,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: latestProducts.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.only(right: 16),
                              child: ProductCard(
                                imageUrl: latestProducts[index].imageUrl,
                                productName: latestProducts[index].productName,
                                price: latestProducts[index].price,
                                offerPrice: latestProducts[index].offerPrice,
                              ),
                            );
                          },
                        ),
                      ),
                      SizedBox(height: 14),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ImageAssets {
  static const List<String> sliderImages = [
    'https://img.freepik.com/premium-vector/sale-banner-promotion-with-red-background-super-offer-banner-template_497837-1623.jpg?w=2000',
    'https://img.freepik.com/premium-vector/big-sale-banner-template-design-abstract-sale-banner-promotion-special-offer-up-15-percent-off_696157-19.jpg?w=2000',
    'https://img.freepik.com/free-vector/biggest-discount-sale-banner_1017-7945.jpg?t=st=1719145266~exp=1719148866~hmac=6fe9557a017aeb6aa74c8e0238590d37682c06f69d44e61b3c068d5420023871&w=2000',
    'https://img.freepik.com/premium-vector/super-sale-banner-with-editable-text-effect_535749-512.jpg?w=2000',
  ];
}
